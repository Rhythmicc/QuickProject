# QuickProject

## usage:
  
  - run `Qpro -add [scripts split by ' ']` to add scripts into your CLion Projects

## author
  - RhythmLian
