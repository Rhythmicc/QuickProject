default_custom_command_template = \
    """const completionSpec: Fig.Spec = __CUSTOM_COMMAND_SPEC__;
export default completionSpec;
"""
