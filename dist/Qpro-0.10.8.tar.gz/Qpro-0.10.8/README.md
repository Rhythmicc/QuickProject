# QuickProject

Do you know how to write Python functions? Yes? Then you now know how to build command-line applications!

## Docs
|Location|Url|
|:---:|:---:|
|China|[Docs](https://rhythmlian.cn/2020/02/14/QuickProject/)|
|Other|[Docs](https://rhythmicc.github.io/2020/02/14/QuickProject/)|

## Manual Install
```shell
git clone https://github.com/Rhythmicc/QuickProject.git
cd QuickProject
python setup.py install
```
